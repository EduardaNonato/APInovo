﻿using System.ComponentModel.DataAnnotations;

namespace APIAlmoxerifado.Models
{
    public class Categoria
    {
        public static string nome { get; internal set; }
        [Key]
        public int Id { get; set; }
        public string Descricao { get; set; }
        public string Nome { get; set; }
    }
}
