﻿using APIAlmoxerifado.Models;
using Microsoft.EntityFrameworkCore;

namespace APIAlmoxerifado.Infraestrutura
{
    public class ConexaoSQL : DbContext
    {
        protected override void OnConfiguring(DbContextOptionsBuilder optionBuilder)
            =>
              optionBuilder.UseSqlServer(
                  @"Server=sql.bsite.net\MSSQL2016;" +
                  "Database=almoxerifado_;" +
                  "User id=almoxerifado_;" +
                  "Password=123456789"


              );

         public DbSet<Produto> Produto { get; set; }
         public DbSet<Categoria> Categoria { get; set; }

    }
}
