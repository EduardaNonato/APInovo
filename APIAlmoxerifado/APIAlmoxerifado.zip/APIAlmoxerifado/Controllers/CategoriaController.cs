﻿using APIAlmoxerifado.Models;
using APIAlmoxerifado.Repository;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Mvc;
using System.Security.Cryptography.X509Certificates;
using System.Web.Http;
using FromBodyAttribute = System.Web.Http.FromBodyAttribute;
using HttpGetAttribute = System.Web.Http.HttpGetAttribute;
using HttpPostAttribute = System.Web.Http.HttpPostAttribute;
using RouteAttribute = Microsoft.AspNetCore.Components.RouteAttribute;

namespace APIAlmoxerifado.Controllers
{
    [Route("api/[controller")]
    [ApiController]


    public class CategoriaController : ControllerBase
    {

        private readonly ICategoriaRepository _CategoriaRepository;
        private List<Categoria> _Categoria;
        private object categoria;

        public CategoriaController(ICategoriaRepository repositorio)
        {
            _CategoriaRepository = repositorio;
        }

        public CategoriaController()
        {

            _Categoria = new List<Categoria>()
            {

                new Categoria { Id = 1, Nome = "Categoria 1", Descricao = "Descricao da Categoria 1" },
              new Categoria { Id = 2, Nome = "Categoria 2", Descricao = "Descricao da Categoria 2" }
            };

        }

        [HttpGet]
        ActionResult<IEnumerable<Categoria>>Get() 
        {
            return _Categoria;
        }
        [HttpGet]
        public ActionResult<Categoria> Get (int Id)
        {
            var categoria = _Categoria.Find(x => x.Id == Id);
            if (categoria == null) 
            { 
                return NotFound();
            }
            return Ok (categoria);

        }
        [HttpPost]
        public ActionResult<Categoria> Post([FromBody] Categoria categoria)
        {
            categoria.Id = _Categoria.Count + 1;  
            _Categoria.Add(categoria);
            CreatedAtAction(nameof(Get), new { Id = categoria.Id }, categoria);
        }
        [HttpGet]
        public IActionResult Put(int id, [FromBody] Categoria categoria) 
        {
            var CategoriaExistente = _Categoria.FirstOrDefault(x => x.Id == id);

            if (CategoriaExistente == null)
            {
                return NotFound();
            }
            CategoriaExistente.Descricao = categoria.Descricao;
            {
                return Ok(CategoriaExistente);
            }
        }
        public IHttpActionResult Delete(int id)
        {
            var categoria = categoria.FirstOrdeFault(c => c.Id == id);
            if (categoria == null)
            {
                return (IHttpActionResult)NotFound();
            }
            categoria.Remove(categoria);
            {
                return Ok(categoria);
            }
        }





    }
}



    