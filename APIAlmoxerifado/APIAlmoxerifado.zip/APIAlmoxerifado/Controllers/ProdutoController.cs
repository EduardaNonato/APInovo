﻿using APIAlmoxerifado.Models;
using APIAlmoxerifado.Repository;
using APIAlmoxerifado.ViewModel;
using Microsoft.AspNetCore.Mvc;
using System.Linq.Expressions;

namespace APIAlmoxerifado.Controllers
{

    [ApiController]
    [Route("[controller]")]
    public class ProdutoController : ControllerBase
    {
         private readonly IProdutoRepository  _produtosRepository;

        public ProdutoController(IProdutoRepository repositorio)
        {
            _produtosRepository = repositorio;
        }

        [HttpGet]
        [Route("api/v1/produto")]
        public IActionResult hello()
        {
            return Ok("hello mundo");
        }
        [HttpGet]
        [Route("GetAllFake")]
        public IActionResult GetAllFake() 
        {
            var produtos = new List<Produto>()
            {
                new Produto()
                {
                    id= 1,
                    nome= "PC HP",
                    estoque= 10
                },
                new Produto()
                {
                    id= 2,
                    nome= "PC DELL",
                    estoque=20
                }
            };
            return Ok(produtos);
        }

        [HttpGet]
        [Route("GetAll")]
        public IActionResult GetAll()
        {
           
            return Ok(_produtosRepository.GetAll());
        }
        [HttpGet]
        [ Route("AdicionarProdutoSemFoto")]
        public IActionResult AdicionarProdutoSemFoto(ProdutoViewModelSemFoto produto)
        {
            try
            {
                _produtosRepository.Add(
               new Produto() { nome = produto.nome, estoque = produto.estoque, photourl = null }
                );
                return Ok("Cadastrado com Sucesso");
            }
            catch (Exception ex)
            {
                return BadRequest("Não Cadastrado. Erro" + ex.Message);
            }
            
               
        }
        [HttpGet]
        [Route("AdicionarProdutoComFoto")]
        public IActionResult AdicionarProdutoSComFoto([FromForm] ProdutoViewModelComFoto produto)
        {
            try
            {
                var caminho = Path.Combine("Storage", produto.photo.FileName);

                using Stream fileStream = new FileStream(caminho, FileMode.Create);
                produto.photo.CopyTo(fileStream);

                _produtosRepository.Add(
               new Produto() { nome = produto.nome, estoque = produto.estoque, photourl = caminho }
                );
                return Ok("Cadastrado com Sucesso");
            }
            catch (Exception ex)
            {
                return BadRequest("Não Cadastrado. Erro" + ex.Message);
            }


        }
        [HttpGet]
        [Route("(id)/GetProduto")]
        public IActionResult GetFoto(int id)
        {
            try
            {
                var produto = _produtosRepository.GetAll().Find(x => x.id == id);
                if (produto.photourl == null)
                {
                    return Ok("Não existe falta cadastrada para o Produto");
                }
                else
                {
                    var dataBytes = System.IO.File.ReadAllBytes(produto.photourl);
                    return File(dataBytes, "image/jpg");

                }

            }
            catch (Exception ex)
            {

                return BadRequest("Erro em fazer download: " + ex.Message);
            }
        }
    }
}
