﻿namespace APIAlmoxerifado.ViewModel
{
    public class CategoriaViewModel
    {
        public int Codigo { get; set; }  
        public string Descricao { get; set;}
    }
}
