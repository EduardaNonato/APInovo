﻿namespace APIAlmoxerifado.ViewModel
{
    public class ProdutoViewModelSemFoto
    {
        public string nome { get; set; }
        public int estoque { get; set; }
    }
}
