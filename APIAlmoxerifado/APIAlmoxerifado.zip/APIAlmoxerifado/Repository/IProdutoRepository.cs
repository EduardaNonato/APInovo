﻿using APIAlmoxerifado.Models;

namespace APIAlmoxerifado.Repository
{
    public interface IProdutoRepository
    {
      List<Produto> GetAll();

        void Add(Produto produto);
    }
}
