﻿using APIAlmoxerifado.Infraestrutura;
using APIAlmoxerifado.Models;

namespace APIAlmoxerifado.Repository
{
    public class CategoriaRepository : ICategoriaRepository
    {
        ConexaoSQL bdConexao = new ConexaoSQL();

        public void Add(Categoria Categoria)
        {
            bdConexao.Add(Categoria);
            bdConexao.SaveChanges();
        }

        public List<Categoria> GetAll()
        {
            return bdConexao.Categoria.ToList();
        }
    }
}
