﻿using APIAlmoxerifado.Models;

namespace APIAlmoxerifado.Repository
{
    public interface ICategoriaRepository
    {
        List<Categoria> GetAll();

        void Add(Categoria Categoria);
    }
}